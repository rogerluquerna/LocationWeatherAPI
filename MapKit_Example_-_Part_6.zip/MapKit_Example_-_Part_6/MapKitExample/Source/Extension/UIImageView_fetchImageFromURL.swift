//
//  UIImageView_fetchImageFromURL.swift
//  IOS2-MapKit


import UIKit

extension UIImageView {
    
    func fetchUImageFromURL(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
    
}


