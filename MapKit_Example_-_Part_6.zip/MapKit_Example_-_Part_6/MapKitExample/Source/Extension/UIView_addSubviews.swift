//
//  UIView_addSubviews.swift
//  MapKitExample


import Foundation
import UIKit


extension UIView {
        
    func addSubviews( _ subviews : UIView... ) {
        
        for subview in subviews {
            self.addSubview(subview)
        }
        
    }
    
}
