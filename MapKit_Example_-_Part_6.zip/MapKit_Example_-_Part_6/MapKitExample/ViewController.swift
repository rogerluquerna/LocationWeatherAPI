//
//  ViewController.swift
//  MapKit


import UIKit
import MapKit

/*
 ok 1. Update our coordinatePanel
 ok 2. Pin the position
 ok 3. Center the map when "target" button is
 tapped
 4. Create UIAddressPanel
 5. Fetch the address using geocoding
 (coordinates)
 
 */

class ViewController: UIViewController, UICoordinatePanelProtocol, CLLocationManagerDelegate, MKMapViewDelegate, UIAddressPanelDelegate {
    
    
    
    
    private var mapView : MKMapView = MKMapView()
    
    private var locationManager = CLLocationManager()
    
    private var coordinate = CLLocationCoordinate2D()
    
    private var coordinatePanel : UICoordinatePanel = UICoordinatePanel()
    
    private var addressPanel : UIAddressPanel = UIAddressPanel()
    
    private var weatherPanel : UIWeatherPanel = UIWeatherPanel()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        initialize()
        
    }
    
    
    private func initialize(){
        
        self.view.addSubviews(self.mapView, self.coordinatePanel, self.addressPanel, self.weatherPanel)
        
        self.coordinatePanel.delegate = self
        self.mapView.delegate = self
        self.locationManager.delegate = self
        
        self.addressPanel.delegate = self
        
        self.weatherPanel.isHidden = true
        
        
        applyConstraints()
        
        
    }
    
    private func applyConstraints() {
        
        coordinatePanel.leadingAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        coordinatePanel.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor).isActive = true
        coordinatePanel.trailingAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.trailingAnchor).isActive = true
        coordinatePanel.heightAnchor.constraint(equalToConstant: 60).isActive = true
        
        
        mapView.translatesAutoresizingMaskIntoConstraints = false
        mapView.leadingAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        mapView.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor).isActive = true
        mapView.trailingAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.trailingAnchor).isActive = true
        mapView.bottomAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.bottomAnchor).isActive = true
        
        
        addressPanel.leadingAnchor.constraint(equalTo: mapView.leadingAnchor).isActive = true
        addressPanel.trailingAnchor.constraint(equalTo: mapView.trailingAnchor).isActive = true
        addressPanel.bottomAnchor.constraint(equalTo: mapView.bottomAnchor).isActive = true
        addressPanel.heightAnchor.constraint(equalToConstant: 80).isActive = true
        
        
        weatherPanel.leadingAnchor.constraint(equalTo: coordinatePanel.leadingAnchor).isActive = true
        weatherPanel.topAnchor.constraint(equalTo: coordinatePanel.bottomAnchor, constant: 20).isActive = true
        
        
    }
    
    func CoordinatePanelMapCenterTapped() {
        
        startUpdatingLocation()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        startUpdatingLocation()   // call the location manager to get gps/position
        
    }
    
    func startUpdatingLocation() {
        
        self.locationManager.desiredAccuracy = kCLLocationAccuracyBest
        self.locationManager.requestWhenInUseAuthorization() // ask the user for permission
        self.locationManager.startUpdatingLocation()  // starts pooling the location
        
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        if let location = locations.first {
            
            self.locationManager.stopUpdatingLocation()  // stops the location pooling
            
            setMapLocation(location: location)
            
        }
        
    }
    
    func setMapLocation( location : CLLocation ) {
        
        self.coordinate = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
        showMap( coordinate: self.coordinate, latLongDelta : 0.002 )
        
        
        coordinatePanel.longitude = location.coordinate.longitude
        coordinatePanel.latitude = location.coordinate.latitude
        
        
        locationManager.getAddress(from: self.coordinate, successHandler: locationManagerGetAddressSuccess, failHandler: locationManagerGetAddressFail)
        
        
        
        // Pin the position
        let pin = MKPointAnnotation()
        pin.title = "You are here!"
        pin.subtitle = "This is the subtitle"
        pin.coordinate = self.coordinate
        mapView.addAnnotation(pin)
        
    }
    
    
    func locationManagerGetAddressSuccess(_ address : String, _ city : String){
        
        addressPanel.address = address
        addressPanel.isHidden = false
        
        WeatherAPI.weatherNow(city: city, successHandler: weatherNowSuccessHandler, failHandler: weatherNowFailHandler)
        
    }
    
    func weatherNowSuccessHandler(_ httpStatusCode : Int, _ response : [String: Any]) {
        
        if httpStatusCode == 200 {
            
            guard let current = response["current"] as? [String: Any] else {
                return
            }
            
            if let currentWeather = WeatherAPICurrent.decode(json: current){
                
                DispatchQueue.main.async {
                    self.weatherPanel.temperature = String(format:"%.0f", currentWeather.temp_c)
                    self.weatherPanel.feelsLike = String(format:"%.0f", currentWeather.feelslike_c)
                    self.weatherPanel.condition = currentWeather.condition.text
                    self.weatherPanel.imageFromUrl(url: "https:\(currentWeather.condition.icon)")
                    
                    self.weatherPanel.isHidden = false
                }
                
            }
        }
        
    }
    
    func weatherNowFailHandler(_ httpStatusCode : Int, _ errorMessage: String) {
        
        DispatchQueue.main.async {
            self.weatherPanel.isHidden = true
        }
        
    }
    
    
    
    
    func locationManagerGetAddressFail() {
        
        print("Error fetching address")
        
    }
    
    func showMap( coordinate : CLLocationCoordinate2D, latLongDelta : Float) {
        
        let span = MKCoordinateSpan(latitudeDelta: CLLocationDegrees(latLongDelta), longitudeDelta: CLLocationDegrees(latLongDelta))
        // MKCoordinateSpan is the width and height in degress for the mapview.
        // 0.001 is street level and 1-10 is a zoom out
        
        let region = MKCoordinateRegion(center: coordinate, span: span)
        
        mapView.setRegion(region, animated: true)
        
    }
    
    
    func addressPanelCloseButtonTapped() {
        
        self.addressPanel.isHidden = true
        
    }
    
}

